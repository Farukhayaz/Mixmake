import React, { useState } from "react";
import AppRoutes from "./routes";
// import Form from "./form";
const App = () => {




    return (


        <div>
            <AppRoutes />
            {/* <Form /> */}
        </div>



    )
}


export default App